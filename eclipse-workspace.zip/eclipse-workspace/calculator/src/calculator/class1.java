package calculator;

import javax.swing.JFrame;

public class class1 {
	
		public static void main(String args[]) {

			JFrame frm= new JFrame("first program");
			frm.setSize(200,400);
			frm.setVisible(true);

		JTextArea.t t=
		}
}
