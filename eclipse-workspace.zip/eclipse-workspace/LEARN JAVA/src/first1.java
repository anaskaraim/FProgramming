
public class first1 {
	public static void main (string[]args){
		
		System.out.println("anas");
	}

}
